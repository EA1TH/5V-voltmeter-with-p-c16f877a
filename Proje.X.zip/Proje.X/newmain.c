#include <pic16f877a.h>
#include <xc.h>
#include "I2C_LCD.h"
#include <stdio.h>
#pragma config FOSC = XT 
#pragma config WDTE = OFF 
#pragma config PWRTE = OFF 
#pragma config BOREN = ON 
#pragma config LVP = ON 
#pragma config CPD = OFF 
#pragma config WRT = OFF 
#pragma config CP = OFF 
#define _XTAL_FREQ 4000000

void main(void) {
   int deger =0;
   int kontrol=0;
   int anlikdeger=0;
   char char_volt[15];
   float volt=0;
   float volt1=0;
   float volt2=0;
   float volt3=0;
   float carpan=0.0048828125;
   TRISA=0XFF; 
   TRISB=0XFF; 
   TRISD=0X00; 
   PORTD=0X00; 
   ADCON0bits.ADON=1; 
   ADCON1bits.PCFG0 =0; 
   ADCON1bits.PCFG1 =0;
   ADCON1bits.PCFG2 =0;
   ADCON1bits.PCFG3 =0;
   ADCON1bits.ADFM =1; 
   
   I2C_Master_Init();
   LCD_Init(0x4E); 
   LCD_Set_Cursor(1, 1);
   LCD_Write_String("Ogrenci Numarasi");
   LCD_Set_Cursor(2, 1);
   LCD_Write_String("B200104036");
   __delay_ms(1000);
   LCD_Clear();
   LCD_Set_Cursor(1, 4);
   LCD_Write_String("Ogrenci Ismi");
   LCD_Set_Cursor(2, 1);
   LCD_Write_String("Eren Al");
   __delay_ms(1000);
   LCD_Clear();
 
  while(1)
  {
   ADCON0bits.CHS0=1;
   ADCON0bits.GO =1; 
   while(ADCON0bits.GO_nDONE);
   deger = ADRESH*256 + ADRESL; 
   volt = deger*carpan;
   
   if(PORTBbits.RB0==1){
       if(kontrol==0){
           kontrol =4;
           while(PORTBbits.RB0);
       }
       else if(kontrol==4){
           kontrol =3;
           while(PORTBbits.RB0);
       }
       else if(kontrol==3){
           kontrol =2;
           while(PORTBbits.RB0);
       }
       else if(kontrol==2){
           kontrol =4;
           while(PORTBbits.RB0);
       }
      
   }
   if(PORTBbits.RB1==1){
       if(kontrol==0){
           kontrol =2;
           while(PORTBbits.RB1);
       }
       else if(kontrol==2){
           kontrol =3;
           while(PORTBbits.RB1);
       }
       else if(kontrol==3){
           kontrol =4;
           while(PORTBbits.RB1);
       }
       else if(kontrol==4){
           kontrol =2;
           while(PORTBbits.RB1);
       }
   }
   if(PORTBbits.RB2==1){
       if(anlikdeger==0){
            volt3=volt2;
            volt2=volt1;
            volt1=volt;}
       if(anlikdeger==1){
           anlikdeger=0;
           kontrol=0;
       }
       if(anlikdeger==2){
           anlikdeger=0;
           kontrol=0;
       }
       while(PORTBbits.RB2);
   }
   
   if(anlikdeger == 0){
       
        __delay_ms(50);
        LCD_Clear();
        sprintf(char_volt,"%.2f",volt);
        LCD_Set_Cursor(1, 2); 
        LCD_Write_String("Olculen Voltaj:");
        LCD_Set_Cursor(2, 7); 
        LCD_Write_String(char_volt); 

   }
   if(kontrol == 2){
       anlikdeger=2; 
       LCD_Clear();
        sprintf(char_volt,"%.2f",volt1);
        LCD_Set_Cursor(1, 4); 
        LCD_Write_String("ilk deger:");
        LCD_Set_Cursor(2, 7); 
        LCD_Write_String(char_volt);
        __delay_ms(50);}
   if(kontrol == 3){
       anlikdeger=2; 
       LCD_Clear();
        sprintf(char_volt,"%.2f",volt2);
        LCD_Set_Cursor(1, 2); 
        LCD_Write_String("ikinci  deger:");
        LCD_Set_Cursor(2, 7); 
        LCD_Write_String(char_volt);
        __delay_ms(50);}
   if(kontrol == 4){
       anlikdeger=2; 
       LCD_Clear();
        sprintf(char_volt,"%.2f",volt3);
        LCD_Set_Cursor(1, 2); 
        LCD_Write_String("ucuncu  deger:");
        LCD_Set_Cursor(2, 7); 
        LCD_Write_String(char_volt);
        __delay_ms(50); }
  }
  return;
}
